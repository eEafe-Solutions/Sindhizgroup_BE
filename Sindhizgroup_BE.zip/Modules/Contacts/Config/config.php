<?php

return [
    'name' => 'Contacts'
];
