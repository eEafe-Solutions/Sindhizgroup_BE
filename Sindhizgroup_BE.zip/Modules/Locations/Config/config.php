<?php

return [
    'name' => 'Locations'
];
