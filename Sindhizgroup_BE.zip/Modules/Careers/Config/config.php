<?php

return [
    'name' => 'Careers'
];
