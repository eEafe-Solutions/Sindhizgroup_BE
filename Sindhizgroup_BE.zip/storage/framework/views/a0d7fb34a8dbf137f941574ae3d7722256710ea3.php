<!DOCTYPE html>
<html>

<head>
    <style>
        .button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
    </style>
</head>

<body>
<center>

    <div style="padding-top:10%;padding-left:40%;">
        <h1>Your request is submitted</h2>


        <p>Thank you for your interest in Sindhiz Group. Our hr team will get back to you as soon.</p>

    </div>

</center>
</body>

</html><?php /**PATH C:\xampp\htdocs\Sindhizgroup_backend\Sindhizgroup_BE\resources\views/contactusermail.blade.php ENDPATH**/ ?>